package Modle;

import javax.persistence.*;

@Entity
public class ImageUpload {
    private String contentType;
	public ImageUpload() {
		super();
		
	}
	public ImageUpload(  String contentType) {
		super();

		this.contentType = contentType;
	}
	
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

 
}
