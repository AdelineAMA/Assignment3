import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@WebServlet("/saveStudents")
@MultipartConfig
public class SaveStudents extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String UPLOAD_DIRECTORY = "uploads";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);

        if (!isMultipart) {
            response.getWriter().println("No file uploaded");
            return;
        }

      
        DiskFileItemFactory factory = new DiskFileItemFactory();

        // Set factory constraints
        factory.setSizeThreshold(1024 * 1024 * 10); // 10 MB
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));


        ServletFileUpload upload = new ServletFileUpload(factory);

      nt
        upload.setSizeMax(1024 * 1024 * 50); // 50 MB

        try {

            List<FileItem> items = upload.parseRequest(request);

            for (FileItem item : items) {
                
                if (!item.isFormField()) {
                    String fileName = new File(item.getName()).getName();
                    String filePath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY + File.separator + fileName;
                    File storeFile = new File(filePath);

                    
                    item.write(storeFile);
                    response.getWriter().println("File " + fileName + " uploaded successfully!");
                }
            }
        } catch (Exception e) {
            response.getWriter().println("File upload failed due to " + e);
        }
    }
}
